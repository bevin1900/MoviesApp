//
//  HomeCollectionViewCell.swift
//  Movie App
//
//  Created by MAC193 on 1/9/19.
//  Copyright © 2019 MAC193. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
    static let reuseIdentifier = "HomeCollectionViewCell"
}
